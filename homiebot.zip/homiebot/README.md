# homiebot
When you lonely, call up homie.
  (he always has your back!!!!)
  Homie Bot is your virtual fun guy to keep you vibin through these tough times!!!
    Our boy no qwestion will turn that frown upside down!!!

Things Homie Bot can do:
  &8ball <question> - ask 8 ball a question, and you will recieve a fun answer!
  &covid - gives you current COVID-19 data so you can stay home and be safe!
  &trivia - asks an interesting trivia question, gives multiple choices, followed by an answer
  &joke - tells a joke :)
  &meme - shows you a meme :O
  &crown - shows you what you dropped >:)
  &rps <rock, paper, or scissors> - plays a game of rock paper scissors with you
  &translate <word> - translates your word into english
  &shibe - sends a picture of a shiba
  &naptime - Homie Bot logs off
